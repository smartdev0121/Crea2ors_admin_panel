import MyProfile from "./MyProfile";

export default MyProfile;
