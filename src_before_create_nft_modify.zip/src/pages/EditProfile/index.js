import EditProfile from "./EditProfile";

export default EditProfile;
