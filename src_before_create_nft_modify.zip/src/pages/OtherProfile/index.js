import OtherProfile from "./OtherProfile";

export default OtherProfile;
