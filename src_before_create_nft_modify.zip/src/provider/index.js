import MetamaskProvider from "./MetamaskProvider";

export default MetamaskProvider;
