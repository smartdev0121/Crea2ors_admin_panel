import MRootModal from "./MRootModal";

export default MRootModal;
