import ConfirmEmailModal from "./ConfirmEmailModal";

export default ConfirmEmailModal;
