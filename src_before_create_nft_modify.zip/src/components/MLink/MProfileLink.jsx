import styled from "styled-components";
import { Link } from "react-router-dom";

const MProfileLink = styled(Link)`
  color: black;
  &:hover {
    color: black;
  }
`;

export default MProfileLink;
