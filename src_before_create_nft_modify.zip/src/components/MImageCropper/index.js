import MImageCropper from "./MImageCropper";

export default MImageCropper;
