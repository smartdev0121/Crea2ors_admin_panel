const NotFoundPage = () => {
  return <div>404 Not Found</div>
}

export default NotFoundPage
