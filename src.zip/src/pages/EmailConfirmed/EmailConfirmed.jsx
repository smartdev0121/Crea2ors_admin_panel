import React from "react";
import { Container, Box, Stack } from "@mui/material";
import { Verified } from "@mui/icons-material";
import { Link } from "react-router-dom";
import { useParams } from "react-router";
import { useDispatch } from "react-redux";
import jwt from "jsonwebtoken";

const EmailConfirmed = () => {
  const dispatch = useDispatch();
  const { token, email } = useParams();
  try {
    const { payload } = jwt.verify(token, process.env.APP_SECRET, {
      complete: true,
    });
    if (!(payload && payload.email === email)) {
      window.location = "/sign-up";
    }
  } catch (error) {
    window.location = "/sign-in";
  }

  return (
    <Container maxWidth="xs" sx={{ marginTop: "100px", marginBottom: "20px" }}>
      <Box
        sx={{
          p: 2,
          backgroundColor: "#36363666",
          padding: "20px",
        }}
      >
        <section className="header">
          <Verified
            fontSize="large"
            sx={{
              backgroundColor: "#da4bfd",
              borderRadius: "50%",
              padding: "5px",
              color: "white",
            }}
          />
          <h2>Congratulations!</h2>
          <p>Your Email is Confirmed!</p>
        </section>

        <section className="link-part">
          <Link to="/sign-in">Sign In</Link>
        </section>
      </Box>
    </Container>
  );
};

export default EmailConfirmed;
