import NFTView from "./NFTView";

export default NFTView;
