import CreateNFTPage from "./CreateNFTPage";

export default CreateNFTPage;
